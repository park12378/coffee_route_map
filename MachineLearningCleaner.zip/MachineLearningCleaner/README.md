# ☕ 반달곰 커피 찾기 프로젝트

**코디세이 AI 올인원 프로그램** - 데이터 분석 및 최단경로 탐색 시스템

## 📋 프로젝트 개요

3단계 파이프라인으로 구성된 데이터 분석 및 BFS 경로 탐색 프로젝트입니다.

- **1단계**: CSV 데이터 분석 및 전처리
- **2단계**: Matplotlib 지도 시각화 
- **3단계**: BFS 알고리즘 최단경로 탐색

## 🚀 실행 방법

### 필수 라이브러리 설치
```bash
pip install pandas matplotlib streamlit
```

### 단계별 실행
```bash
# 1단계: 데이터 분석
python caffee_map_final.py

# 2단계: 지도 시각화  
python map_draw_real.py

# 3단계: 최단경로 탐색
python map_direct_save.py

# 웹 대시보드 실행
streamlit run app.py
```

## 📊 파일 구조

```
📁 프로젝트/
├── 🐍 caffee_map_final.py    # 1단계: 데이터 분석
├── 🗺️ map_draw_real.py       # 2단계: 지도 시각화
├── 🎯 map_direct_save.py     # 3단계: BFS 경로탐색
├── 🌐 app.py                 # Streamlit 웹 대시보드
├── 📋 area_map.csv           # 좌표 데이터
├── 🏗️ area_struct.csv        # 구조물 데이터
├── 📝 area_category.csv      # 구조물 카테고리
├── 🖼️ map.png               # 생성된 지도
├── 🖼️ map_final.png         # 경로 포함 지도
└── 📄 home_to_cafe.csv       # 최단경로 좌표
```

## 🔧 기술 스택

- **Python 3.11+** 
- **Pandas**: 데이터 처리
- **Matplotlib**: 시각화
- **Streamlit**: 웹 대시보드
- **BFS 알고리즘**: 최단경로 탐색

## 📈 주요 기능

1. **실제 CSV 데이터 처리**: 3개 파일 병합 및 전처리
2. **전체 지도 시각화**: 15x15 격자에 구조물과 장애물 표시
3. **BFS 경로 탐색**: MyHome(14,2)에서 BandalgomCoffee(2,12)까지 24칸 최단경로
4. **인터랙티브 웹 대시보드**: 단계별 결과 확인

## 🎯 실행 결과

- **총 경로 길이**: 24칸 (25단계)
- **격자 크기**: 225개 셀 (15×15)
- **장애물 수**: 76개 (건설현장, 아파트, 빌딩)

## 🏆 프로젝트 특징

- PEP 8 준수 코딩 스타일
- pandas와 matplotlib만 사용한 제약 조건
- 실제 데이터 기반 현실적 경로 탐색
- 3개 파일로 구성된 모듈식 설계