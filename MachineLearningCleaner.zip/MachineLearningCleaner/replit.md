# Coffee Map Project - 반달곰 커피를 찾아서

## Overview

This is a complete data analysis and pathfinding project that successfully processes real CSV data, creates visualizations, and finds optimal routes using BFS algorithms. The project consists of three working stages: data collection and analysis, map visualization, and shortest path finding.

**Status**: All stages completed and fully functional with real data integration.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

This is a Python-based data analysis and visualization project with a three-stage pipeline architecture:

1. **Data Processing Layer** (`caffee_map.py`) - Handles CSV data loading, merging, and preprocessing
2. **Visualization Layer** (`map_draw.py`) - Creates map visualizations using matplotlib
3. **Pathfinding Layer** (`map_direct_save.py`) - Implements shortest path algorithms

The architecture follows a sequential processing pattern where each stage depends on the output of the previous stage.

## Key Components

### Data Management
- **CSV Data Sources**: Three main data files
  - `area_map.csv` - Contains coordinate and area information
  - `area_struct.csv` - Contains structure/building data with IDs
  - `area_category.csv` - Maps structure IDs to readable names
- **Data Processing**: Pandas-based ETL pipeline for merging and filtering data
- **Area Filtering**: Focuses specifically on area 1 where the coffee shop is located

### Visualization Engine
- **Matplotlib Backend**: Uses matplotlib for 2D map rendering
- **Grid System**: Implements coordinate-based grid visualization
- **Symbol Mapping**: Different shapes and colors for different structure types:
  - Brown circles for apartments and buildings
  - Green squares for coffee shops
  - Green triangles for home locations
  - Gray squares for construction sites

### Pathfinding System
- **Algorithm Implementation**: BFS (Breadth-First Search) for shortest path calculation
- **Start/End Point Detection**: Automatically identifies home and coffee shop locations
- **Route Optimization**: Finds optimal path avoiding obstacles

## Data Flow

1. **Stage 1 (Data Collection)**:
   - Load CSV files → Merge structure data with categories → Filter for area 1 → Output processed dataset

2. **Stage 2 (Visualization)**:
   - Load processed data → Create coordinate system → Map structures to visual elements → Generate PNG output

3. **Stage 3 (Pathfinding)**:
   - Load processed data → Identify start/end points → Apply BFS algorithm → Calculate shortest route

## External Dependencies

- **pandas**: Primary data manipulation and analysis library
- **matplotlib**: Visualization and plotting framework
- **matplotlib.patches**: For drawing geometric shapes on maps
- **collections.deque**: For BFS queue implementation
- **csv**: Built-in CSV handling (backup to pandas)

## Deployment Strategy

This is a standalone Python application designed to run in environments with scientific computing libraries. The project:

- Processes local CSV files as data sources
- Generates static PNG output files
- Operates as a batch processing system
- Requires Python 3.x with scientific computing stack (pandas, matplotlib)

### File Structure
```
project/
├── caffee_map_final.py    # Stage 1: Data processing (WORKING)
├── map_draw_real.py       # Stage 2: Map visualization (WORKING)
├── map_direct_save.py     # Stage 3: Pathfinding with BFS (WORKING)
├── app.py                 # Streamlit web dashboard (WORKING)
├── area_map.csv           # Coordinate data (real data)
├── area_struct.csv        # Structure data (real data)
├── area_category.csv      # Structure categories (real data)
├── map.png                # Generated map output
├── map_final.png          # Map with shortest path
└── home_to_cafe.csv       # Shortest path coordinates
```

## Recent Changes (July 22, 2025)
✓ Successfully adapted all code to work with real CSV data structure
✓ Fixed data processing issues with column spacing and data types
✓ Implemented working BFS pathfinding algorithm
✓ Generated functional map visualizations with matplotlib
✓ Created complete Streamlit web dashboard
✓ All 3 stages now process real data and generate actual outputs

The system is fully functional and successfully processes real data to create a complete coffee shop location and routing solution.