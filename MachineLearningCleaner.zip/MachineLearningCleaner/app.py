"""
Streamlit 웹 애플리케이션: 반달곰 커피 프로젝트 대시보드
"""

import streamlit as st
import pandas as pd
import os
from PIL import Image

# 페이지 설정
st.set_page_config(
    page_title="반달곰 커피 프로젝트",
    page_icon="☕",
    layout="wide"
)

# 제목
st.title("☕ 반달곰 커피 찾기 프로젝트")
st.markdown("**코디세이 AI 올인원 프로그램** - 데이터 분석 및 경로 탐색")

# 사이드바 메뉴
st.sidebar.title("🗺 프로젝트 단계")
stage = st.sidebar.selectbox(
    "단계를 선택하세요:",
    ["프로젝트 소개", "1단계: 데이터 분석", "2단계: 지도 시각화", "3단계: 최단경로 탐색"]
)

# 각 단계별 내용
if stage == "프로젝트 소개":
    st.header("📋 프로젝트 개요")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("""
        ### 🎯 프로젝트 목표
        이 프로젝트는 **3단계 파이프라인**으로 구성된 데이터 분석 및 경로 탐색 시스템입니다.
        
        ### 📊 사용 데이터
        - **area_map.csv**: 좌표 및 건설현장 정보
        - **area_struct.csv**: 구조물 카테고리 및 지역 정보  
        - **area_category.csv**: 구조물 이름 매핑
        
        ### 🔧 기술 스택
        - **Python**: 메인 프로그래밍 언어
        - **Pandas**: 데이터 처리 및 분석
        - **Matplotlib**: 지도 시각화
        - **BFS 알고리즘**: 최단경로 탐색
        
        ### 📈 3단계 프로세스
        1. **데이터 분석**: CSV 파일 병합 및 전처리
        2. **지도 시각화**: Matplotlib를 이용한 시각적 지도 생성
        3. **경로 탐색**: BFS 알고리즘으로 최단경로 계산
        """)
    
    with col2:
        st.subheader("🏗 구조물 종류")
        st.markdown("""
        - 🏠 아파트 (갈색 원)
        - 🏢 빌딩 (갈색 원)
        - ☕ 반달곰커피 (녹색 사각형)
        - 🚧 건설현장 (회색 사각형)
        """)

elif stage == "1단계: 데이터 분석":
    st.header("📊 1단계: 데이터 분석")
    
    # 데이터 불러오기
    try:
        area_map = pd.read_csv('area_map.csv')
        area_struct = pd.read_csv('area_struct.csv')
        area_category = pd.read_csv('area_category.csv')
        
        # 컬럼명과 데이터의 공백 제거
        area_category.columns = area_category.columns.str.strip()
        area_category['struct'] = area_category['struct'].str.strip()
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.subheader("🗺 area_map.csv")
            st.dataframe(area_map.head())
            st.caption(f"총 {len(area_map)}개 좌표")
        
        with col2:
            st.subheader("🏗 area_struct.csv")
            st.dataframe(area_struct.head())
            st.caption(f"총 {len(area_struct)}개 구조물")
        
        with col3:
            st.subheader("📋 area_category.csv")
            st.dataframe(area_category)
            st.caption(f"총 {len(area_category)}개 카테고리")
        
        # 병합된 데이터 표시
        st.subheader("🔗 병합된 데이터 (area 1)")
        
        # 데이터 병합 과정 재현
        merged_data = area_map.merge(area_struct, on=['x', 'y'], how='left')
        area_1_data = merged_data[merged_data['area'] == 1].copy()
        
        st.dataframe(area_1_data.head(10))
        st.caption(f"area 1 데이터: {len(area_1_data)}개 행")
        
        # 구조물별 통계
        st.subheader("📈 구조물별 통계")
        structures = area_1_data[area_1_data['category'] != 0]
        if not structures.empty:
            # 카테고리 매핑
            category_mapping = area_category.set_index('category')['struct'].to_dict()
            
            structure_stats = structures.groupby('category').agg({
                'x': 'count',
                'area': 'first'
            }).rename(columns={'x': '개수', 'area': '지역'})
            
            structure_stats['구조물명'] = structure_stats.index.map(category_mapping)
            
            col1, col2 = st.columns(2)
            with col1:
                st.dataframe(structure_stats[['구조물명', '개수', '지역']])
            
            with col2:
                st.subheader("📍 구조물 위치")
                for category in structures['category'].unique():
                    struct_name = category_mapping.get(category, f'Category_{category}')
                    struct_locations = structures[structures['category'] == category][['x', 'y']]
                    locations = list(zip(struct_locations['x'], struct_locations['y']))
                    st.write(f"**{struct_name}**: {locations}")
        
    except FileNotFoundError as e:
        st.error(f"파일을 찾을 수 없습니다: {e}")

elif stage == "2단계: 지도 시각화":
    st.header("🗺 2단계: 지도 시각화")
    
    if os.path.exists('map.png'):
        st.subheader("생성된 지도")
        
        # 이미지 표시
        image = Image.open('map.png')
        st.image(image, caption="반달곰 커피 지역 지도", use_container_width=True)
        
        # 범례 설명
        st.subheader("🔍 범례 설명")
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("""
            **구조물 표현:**
            - 🟤 갈색 원: 아파트, 빌딩
            - 🟢 녹색 사각형: 반달곰커피
            - ⬜ 회색 사각형: 건설현장
            """)
        
        with col2:
            st.markdown("""
            **좌표계:**
            - X축: 가로 좌표 (1~7)
            - Y축: 세로 좌표 (8~15)
            - 격자: 각 셀은 1x1 크기
            """)
    else:
        st.warning("지도 파일(map.png)이 생성되지 않았습니다. 2단계를 먼저 실행해주세요.")
        
        if st.button("🗺 지도 생성하기"):
            with st.spinner("지도를 생성하는 중..."):
                import subprocess
                result = subprocess.run(['python', 'map_draw_real.py'], capture_output=True, text=True)
                if result.returncode == 0:
                    st.success("지도가 성공적으로 생성되었습니다!")
                    st.rerun()
                else:
                    st.error(f"지도 생성 중 오류 발생: {result.stderr}")

elif stage == "3단계: 최단경로 탐색":
    st.header("🎯 3단계: 최단경로 탐색")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        if os.path.exists('map_final.png'):
            st.subheader("최단경로가 표시된 지도")
            image = Image.open('map_final.png')
            st.image(image, caption="최단경로 시각화", use_container_width=True)
        else:
            st.warning("최단경로 지도(map_final.png)가 생성되지 않았습니다.")
            
            if st.button("🎯 최단경로 찾기"):
                with st.spinner("최단경로를 계산하는 중..."):
                    import subprocess
                    result = subprocess.run(['python', 'map_direct_save.py'], capture_output=True, text=True)
                    if result.returncode == 0:
                        st.success("최단경로가 성공적으로 계산되었습니다!")
                        st.rerun()
                    else:
                        st.error(f"경로 계산 중 오류 발생: {result.stderr}")
    
    with col2:
        # 경로 데이터 표시
        if os.path.exists('home_to_cafe.csv'):
            st.subheader("📊 경로 데이터")
            path_data = pd.read_csv('home_to_cafe.csv')
            st.dataframe(path_data)
            
            st.subheader("📈 경로 정보")
            st.metric("총 이동 거리", f"{len(path_data) - 1}칸")
            st.metric("총 단계 수", f"{len(path_data)}단계")
            
            # 시작점과 끝점 표시
            if len(path_data) > 0:
                start = (path_data.iloc[0]['x'], path_data.iloc[0]['y'])
                end = (path_data.iloc[-1]['x'], path_data.iloc[-1]['y'])
                st.write(f"**시작점**: {start}")
                st.write(f"**도착점**: {end}")
        else:
            st.info("경로 데이터(home_to_cafe.csv)가 아직 생성되지 않았습니다.")

# 푸터
st.markdown("---")
st.markdown("**반달곰 커피 프로젝트** | 코디세이 AI 올인원 프로그램")